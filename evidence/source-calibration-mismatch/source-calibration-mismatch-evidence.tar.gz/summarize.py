from pathlib import Path
import json,hashlib
import numpy as np
P=Path(__file__).resolve().parent;data=json.loads((P/'run-v1/results.json').read_text());rows=[]
for entry in data['rows']:
 key=f"{entry['pattern']}-{entry['seed']}-{entry['plane']}";folder=P/'run-v1/raw'/key;truth=json.loads((folder/'truth.json').read_text());observations=json.loads((folder/'observations.json').read_text())['observations'];result=json.loads((folder/'calibration.json').read_text());checks=[]
 for failure in result['diagnostics']:
  if not isinstance(failure,dict) or 'capture_id' not in failure:continue
  i=int(failure['capture_id'].split('-')[-1]);o=observations[i];t=truth['captures'][i];primary=[p for p in t['paths'] if p['emitter']==0];expected=primary[1]['delay_s']-primary[0]['delay_s'];check=dict(capture_id=failure['capture_id'],eligible_candidates=failure['eligible_candidates'],observation_status=o['status'],all_candidate_delays_s=[c['delay_s'] for c in o.get('candidates',[])],physical_primary_reference_delay_s=expected,generating_primary_reference_to_direct_amplitude=primary[1]['amplitude']/primary[0]['amplitude'])
  if o['status']=='ok':
   y=np.array(o['response']['values']);axis=o['response']['start_delay_s']+np.arange(len(y))/o['response']['sample_rate_hz'];window=abs(axis-expected)<.0001;check['local_primary_reference_peak_to_selected_direct']=float(max(abs(y[window]))/o['quality']['direct_response_amplitude']);check['candidate_amplitude_floor']=.07
  checks.append(check)
 rows.append(dict(case=key,status=result['status'],accepted_recordings=entry['accepted_recordings'],reference_unidentified_captures=checks,runtime_s=entry['runtime_s']))
summary=dict(calibration_sessions=len(rows),proposals=sum(r['status']=='calibration_proposal' for r in rows),single_controls_rejected=4,dual_sessions_rejected=8,false_qualification_comparison='inconclusive: single-source calibration controls fail reference-path visibility',cases=rows,source_hashes_unchanged=data['source_hashes']==json.loads((P/'run-v1/freeze.json').read_text())['source_hashes'],reserved_seeds_used=False)
(P/'run-v1/summary.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items() if k!='cases'})
