"""Postfreeze local information analysis only: no source fitting or raw generation."""
from pathlib import Path
import json,hashlib
import numpy as np
P=Path(__file__).resolve().parent;rho=.003;theta=np.array([1.5,1.5,1.3,343.]);planes=[np.array([1.,0.,0.]),np.array([0.,1.,0.])]
def jac(fn,x):
 columns=[]
 for i in range(len(x)):
  e=np.zeros(len(x));e[i]=1e-5*max(1,abs(x[i]));columns.append((fn(x+e)-fn(x-e))/(2*e[i]))
 return np.array(columns).T
rows=[]
for seed in [2821,2833]:
 sessions=[];observations=[];selected=[];survey=[]
 for plane in ['x','y']:
  f=P/'run-v2/raw'/f'single-{seed}-{plane}';session=json.loads((f/'session.json').read_text());o=json.loads((f/'observations.json').read_text())['observations'];ref=json.loads((f/'reference.json').read_text());normal=np.array(ref['normal']);s=np.array(session['source_position_m']);q=s-2*(s@normal)*normal;items=[]
  for c,obs in zip(session['captures'],o):
   r=np.array(c['receiver_position_m']);excess=np.linalg.norm(r-q)-np.linalg.norm(r-s);eligible=[a for a in obs['candidates'] if max(0,(excess-.3)/380)<=a['delay_s']<=(excess+.3)/300];assert obs['status']=='ok' and len(eligible)==1;items.append(eligible[0])
  sessions.append(session);observations.append(o);selected.append(items);survey.append(ref)
 points=np.array([c['receiver_position_m'] for c in sessions[0]['captures']]);assert np.array_equal(points,np.array([c['receiver_position_m'] for c in sessions[1]['captures']]))
 def all_predictions(t,perturb=None):
  outputs=[]
  if perturb is None:perturb=np.zeros(6)
  for j,n0 in enumerate(planes):
   axis=np.eye(3)[np.argmin(abs(n0))];u=np.cross(n0,axis);u/=np.linalg.norm(u);w=np.cross(n0,u);n=n0+perturb[3*j+1]*u+perturb[3*j+2]*w;n/=np.linalg.norm(n);s=t[:3];q=s+2*(perturb[3*j]-n@s)*n;outputs.extend((np.linalg.norm(points-q,axis=1)-np.linalg.norm(points-s,axis=1))/t[3])
  return np.array(outputs)
 H=jac(all_predictions,theta);G=jac(lambda ref:all_predictions(theta,ref),np.zeros(6));timing=[];D=np.zeros((24,36))
 for j,n in enumerate(planes):
  s=theta[:3];q=s-2*(n@s)*n
  for i,(r,o,c) in enumerate(zip(points,observations[j],selected[j])):
   timing.append(c['delay_std_s']**2+o['direct_std_s']**2+(c['delay_s']*o['clock']['alpha_std']/o['clock']['alpha'])**2);grad=((r-q)/np.linalg.norm(r-q)-(r-s)/np.linalg.norm(r-s))/theta[3];D[j*12+i,3*i:3*i+3]=grad
 Ctiming=np.diag(timing);Creceiver=D@(np.eye(36)*rho**2)@D.T;Cr=np.diag([.003**2,.0005**2,.0005**2]*2);Cref=G@Cr@G.T;C=Ctiming+Creceiver+Cref;trainx=np.arange(8);trainy=np.arange(12,20);joint=np.r_[trainx,trainy];held=np.r_[np.arange(8,12),np.arange(20,24)];comparisons={}
 for label,indices in [('x_only',trainx),('y_only',trainy),('joint_x_y',joint)]:
  A=H[indices];V=C[np.ix_(indices,indices)];information=A.T@np.linalg.solve(V,A);cov=np.linalg.inv(information);std=np.sqrt(np.diag(cov));predstd=np.sqrt(np.einsum('ij,jk,ik->i',H[held],cov,H[held]));comparisons[label]=dict(parameter_covariance=cov.tolist(),source_axis_std_m=std[:3].tolist(),effective_speed_std_m_s=float(std[3]),held_parameter_only_prediction_std_s=predstd.tolist(),source_covariance_eigenvalues_m2=np.linalg.eigvalsh(cov[:3,:3]).tolist())
 rows.append(dict(seed=seed,linearization_source_m=theta[:3].tolist(),linearization_effective_speed_m_s=theta[3],information=comparisons,receiver_cross_reference_covariance_nonzero=bool(np.any(abs(Creceiver[:12,12:])>0)),timing_covariance_min_eigenvalue=float(min(np.linalg.eigvalsh(C))),scope='Conditional local GLS information, no joint nonlinear calibration fit, no truth coordinates/echo labels used.'))
result=dict(rows=rows,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),assumptions=['One shared source x/y/z and effective speed for both isolated references','Per-record candidate/direct/rate timing budgets as current code','Same receiver pose error reused across both references, retained cross-covariance','Independent reference-plane survey errors shared over all captures per plane','No source-parameter prior invented from bounded search radius','No raw/parameter fitting; derivatives at supplied mechanical source and nominal speed'],dual_admission='Both opposite-phase y-reference cases have2eligible candidates at every stop. Keeping the existing exactly-one gate makes joint point calibration unavailable; no labels selected.',limits='Inverse local information is conditional on a correct stationary point source/path model. It does not certify source identity, finite-extent effects, full nonlinear covariance or success of a future joint fit.')
(P/'run-v2/joint-information.json').write_text(json.dumps(result,indent=2)+'\n')
for r in rows:
 print(r['seed'],{k:dict(source_std=v['source_axis_std_m'],speed_std=v['effective_speed_std_m_s']) for k,v in r['information'].items()})
