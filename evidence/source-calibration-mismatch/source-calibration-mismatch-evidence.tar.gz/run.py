"""Frozen distributed-source calibration development experiment; no labels in fit."""
from pathlib import Path
import sys,json,hashlib,subprocess,tarfile,io,time
import numpy as np
from scipy.signal import chirp,fftconvolve
from scipy.signal.windows import tukey
from scipy.io import wavfile
P=Path(__file__).resolve().parent;ROOT=P.parents[1];CORE=P/'core';COMMIT='3745665352f59bc88e432b1f703054ab29398ce1'
SEEDS=[2801,2819];PATTERNS=['single','dual_same_phase','dual_opposite_phase'];NORMALS={'x':np.array([1.,0.,0.]),'y':np.array([0.,1.,0.])}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def hashes():return {str(q.relative_to(P)):sha(q) for q in [P/'PROTOCOL.md',P/'run.py']+sorted((CORE/'echosight').glob('*.py'))}
def setup():
 if not CORE.exists():
  raw=subprocess.run(['git','archive',COMMIT,'echosight'],cwd=ROOT,check=True,capture_output=True).stdout;CORE.mkdir()
  with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(CORE,filter='data')
 sys.path.insert(0,str(CORE))
def probe():
 fs=48000;cfg=dict(sample_rate_hz=fs,duration_s=.04,low_hz=2000.,high_hz=14000.,repetitions=7,period_s=.35,lead_s=.1,tail_s=.18,max_echo_delay_s=.08);pulse=.7*chirp(np.arange(1920)/fs,2000,.04,14000,method='linear')*tukey(1920,.25);starts=[round((.1+i*.35)*fs) for i in range(7)];y=np.zeros(starts[-1]+len(pulse)+round(.18*fs))
 for start in starts:y[start:start+len(pulse)]=pulse
 return y,cfg

def render(folder,pattern,seed,plane):
 folder.mkdir(parents=True,exist_ok=False);rng=np.random.default_rng(seed);points=rng.uniform([.6,1.35,.4],[3.8,1.65,2.7],(12,3));survey=points+rng.normal(0,.003,points.shape);nominal=np.array([1.5,1.5,1.3]);actual=nominal+[.04,-.02,.01];normal=NORMALS[plane];secondary=actual+[0,.24,0];emitters=[(actual,1.)]+([] if pattern=='single' else [(secondary,.8 if pattern=='dual_same_phase' else -.8)])
 emitted,config=probe();emitted=fftconvolve(emitted,[.82,.13,-.045,.025]);fs=48000;session=dict(schema_version='1.0',session_id=folder.name,source_position_m=nominal.tolist(),source_position_std_m=.01,sound_speed_m_s=343.,sound_speed_std_m_s=.6,source_clock_scale=1.,source_clock_std_ppm=80.,probe=config,captures=[]);truth=dict(pattern=pattern,seed=seed,plane=plane,primary_m=actual.tolist(),secondary_m=secondary.tolist() if pattern!='single' else None,receiver_positions_m=points.tolist(),effective_speed_m_s=346.,captures=[])
 for i,r in enumerate(points):
  impulse=np.zeros(round(.16*fs));paths=[]
  for k,(s,gain) in enumerate(emitters):
   image=s-2*(normal@s)*normal;direct=np.linalg.norm(r-s);reflection=np.linalg.norm(r-image)
   for label,length,amplitude in [('direct',direct,.55*gain),('reference',reflection,.20*gain*direct/reflection)]:
    delay=length/346.;center=delay*fs;indices=np.arange(int(np.floor(center))-24,int(np.floor(center))+25);weights=np.sinc(indices-center)*np.hanning(49);weights/=sum(weights);impulse[indices]+=amplitude*weights;paths.append(dict(emitter=k,kind=label,delay_s=float(delay),amplitude=float(amplitude)))
  wave=fftconvolve(emitted,impulse);wave=fftconvolve(wave,[.94,.045,-.018,.006])[:len(wave)];alpha=1+rng.uniform(-250,250)*1e-6;offset=rng.uniform(.04,.10);t=np.arange(len(wave)+round(.15*fs))/fs;clean=np.interp((t-offset)/alpha,np.arange(len(wave))/fs,wave,left=0,right=0);y=.45*(clean+rng.normal(0,.00012,len(clean)));assert max(abs(y))<.95
  name=f'capture-{i:02d}.wav';wavfile.write(folder/name,fs,np.rint(y*32767).astype('<i2'));session['captures'].append(dict(capture_id=f'capture-{i:02d}',receiver_position_m=survey[i].tolist(),receiver_position_std_m=.003,device_id=f'receiver-{i%4}',receiver_pose_group_id=f'receiver-{i}',recording_path=name,provenance='simulated'));truth['captures'].append(dict(capture_id=f'capture-{i:02d}',paths=paths,alpha=alpha,offset_s=offset,raw_sha256=sha(folder/name)))
 reference=dict(normal=normal.tolist(),offset_m=0.,offset_std_m=.003,normal_std_rad=.0005,source_search_radius_m=.15,effective_speed_bounds_m_s=[300.,380.],training_capture_ids=[f'capture-{i:02d}' for i in range(8)],validation_capture_ids=[f'capture-{i:02d}' for i in range(8,12)])
 save(folder/'session.json',session);save(folder/'reference.json',reference);save(folder/'truth.json',truth);save(folder/'manifest.json',dict(raw={p.name:sha(p) for p in folder.glob('*.wav')},truth_sha256=sha(folder/'truth.json')))
 return folder/'session.json'
def evaluate(folder,result):
 truth=json.loads((folder/'truth.json').read_text());out=dict(status=result['status'],diagnostics=result['diagnostics'],training_normalized_rms=result.get('training_normalized_rms'),validation_normalized_rms=result.get('validation_normalized_rms'),validation_fitted_rms_s=result.get('validation_fitted_rms_s'),validation_max_abs_residual_s=result.get('validation_max_abs_residual_s'))
 if 'calibration' in result:
  c=result['calibration'];s=np.array(c['source_position_m']);primary=np.array(truth['primary_m']);out.update(calibration=c,primary_distance_m=float(np.linalg.norm(s-primary)),effective_speed_error_m_s=c['effective_speed_m_s']-truth['effective_speed_m_s'])
  if truth['secondary_m'] is not None:
   second=np.array(truth['secondary_m']);out.update(secondary_distance_m=float(np.linalg.norm(s-second)),midpoint_distance_m=float(np.linalg.norm(s-(primary+second)/2)),interpretation='Distances describe a conditional effective center; no unique physical point truth for dual source.')
 return out

def main():
 setup();out=P/'run-v1';action=sys.argv[1]
 if action=='freeze':
  if (out/'freeze.json').exists():raise FileExistsError('Preserve freeze')
  save(out/'freeze.json',dict(source_hashes=hashes(),runtime_commit=COMMIT,seeds=SEEDS,patterns=PATTERNS,planes=list(NORMALS),before_new_generation=True,time_unix=time.time()));print('Frozen',sha(out/'freeze.json'));return
 assert hashes()==json.loads((out/'freeze.json').read_text())['source_hashes']
 from echosight.calibration import calibrate_reference
 from echosight.pipeline import process_session
 from echosight.storage import load_session
 sessions=[]
 for pattern in PATTERNS:
  for seed in SEEDS:
   for plane in NORMALS:sessions.append((pattern,seed,plane,render(out/'raw'/f'{pattern}-{seed}-{plane}',pattern,seed,plane)))
 save(out/'input-manifests.json',{p.parent.name:sha(p.parent/'manifest.json') for _,_,_,p in sessions});answers={};rows=[]
 for pattern,seed,plane,path in sessions:
  reference=json.loads((path.parent/'reference.json').read_text());start=time.perf_counter();result=calibrate_reference(path,reference);seconds=time.perf_counter()-start;save(path.parent/'calibration.json',result)
  # Independent raw observation replay, never patched into calibration.
  raw_result=process_session(load_session(path));save(path.parent/'observations.json',raw_result)
  answers[(pattern,seed,plane)]=(result,raw_result,path);row=dict(pattern=pattern,seed=seed,plane=plane,runtime_s=seconds,result=evaluate(path.parent,result),accepted_recordings=sum(o['status']=='ok' for o in raw_result['observations']),candidate_counts=[len(o.get('candidates',[])) for o in raw_result['observations']]);rows.append(row);save(out/'partial-results.json',rows);print(pattern,seed,plane,result['status'],result.get('validation_fitted_rms_s'),[d.get('code') if isinstance(d,dict) else d for d in result['diagnostics']],flush=True)
 transfers=[]
 for pattern in PATTERNS:
  for seed in SEEDS:
   a,_,_=answers[(pattern,seed,'x')];b,raw,path=answers[(pattern,seed,'y')]
   if 'calibration' not in a:transfers.append(dict(pattern=pattern,seed=seed,status='unavailable_x_calibration_rejected'));continue
   session=load_session(path);s0=np.array(session['source_position_m']);normal=NORMALS['y'];nominal_image=s0-2*(normal@s0)*normal;cal=a['calibration'];s=np.array(cal['source_position_m']);q=s-2*(normal@s)*normal;records=[]
   for o,c in zip(raw['observations'],session['captures']):
    r=np.array(c['receiver_position_m']);length=np.linalg.norm(r-nominal_image)-np.linalg.norm(r-s0);low=max(0,(length-.3)/380);high=(length+.3)/300;eligible=[cand for cand in o.get('candidates',[]) if low<=cand['delay_s']<=high];pred=(np.linalg.norm(r-q)-np.linalg.norm(r-s))/cal['effective_speed_m_s'];record=dict(capture_id=o['capture_id'],observation_status=o['status'],eligible_candidates=len(eligible),predicted_delay_s=float(pred))
    if o['status']=='ok' and len(eligible)==1:record.update(observed_delay_s=eligible[0]['delay_s'],residual_s=float(pred-eligible[0]['delay_s']))
    records.append(record)
   good=all('residual_s' in r for r in records);transfer=dict(pattern=pattern,seed=seed,status='unique_reference_transfer' if good else 'ambiguous_reference_transfer',records=records)
   if good:
    residual=np.array([r['residual_s'] for r in records]);transfer.update(rms_s=float(np.sqrt(np.mean(residual**2))),max_abs_s=float(max(abs(residual))),passes_existing_absolute_gates=bool(np.sqrt(np.mean(residual**2))<=.0001 and max(abs(residual))<=.0002))
   if 'calibration' in b:transfer['independent_y_proposal_disagreement']=dict(source_distance_m=float(np.linalg.norm(s-np.array(b['calibration']['source_position_m']))),effective_speed_difference_m_s=cal['effective_speed_m_s']-b['calibration']['effective_speed_m_s'])
   transfers.append(transfer)
 assert hashes()==json.loads((out/'freeze.json').read_text())['source_hashes'];save(out/'results.json',dict(rows=rows,transfers=transfers,source_hashes=hashes(),runtime_commit=COMMIT,scope='Development raw isolated-reference model-mismatch experiment; no device qualification or general source identification.'));print('Complete',flush=True)
if __name__=='__main__':main()
