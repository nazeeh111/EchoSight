# State after bounded V2 and information diagnosis

Scope: distributed-source applicability of existing one-plane reference calibration, immutable3745665. No main edits or active jobs. V1all12reject, including4single controls with too-weak references; preserved snapshotb8c1049d8d6d. V2separately frozen stand-off arrangement:4single proposals; in-phase dual rejects bothrefs; opposite-phase x2proposals with~22cm sourceSD, y2rejects with2eligibleechoes at every stop. One single-source x→y transfer fails229/283µs despite one-plane proposal. Do not mislabel this a physical source rejection or hide its covariance.

Known-reference local information, not fitting: jointx/y predicts sourceSD1.65/2.51/1.84cm and speedSD3.85m/s using shared reused-receiver covariance; analytic derivative checks pass. This supports a bounded future joint proposal with unchanged individual path/held gates, not adoption of the failed transfer or a general source qualification claim. Practical burden24recordings/2surveyedisolatedreferences/fixedsource route and orientation.

Artifacts: V2-REPORT.md, V2-PROTOCOL.md, run_v2.py, joint_information.py, run-v2 outputs. Reserved2609/2621 unused. No further raw cases, mainfeature or waveformsearch authorized. Next action: coordinator/independent review of compact archive and decide whether joint-calibration value justifies its acquisition burden.
