from pathlib import Path
import ast,json,hashlib,time,sys
import numpy as np
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import runner
from render import save,sha
source=(runner.ROOT/'tests/test_signals.py').read_text();tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='waveform');scope={'np':np,'generate_probe':runner.module.generate_probe};exec(compile(ast.Module(body=[fn],type_ignores=[]),'waveform_fixture','exec'),scope);waveform=scope['waveform'];rows=[]
def compare(y,fs,p,info):
 row=dict(info)
 for label,m in [('original',runner.process_recording),('candidate',runner.module.process_recording)]:
  start=time.perf_counter();r=m(y,fs,p,'r');row[label]=dict(status=r['status'],clock=r['clock'],diagnostics=r['diagnostics'],candidates=r['candidates'],runtime_s=time.perf_counter()-start)
  if info['kind']=='affine':row[label]['maximum_path_delay_error_s']=max(min([abs(c['delay_s']-d) for c in r['candidates']] or [1.]) for d in [.012345,.026789]) if r['status']=='ok' else None
 rows.append(row)
for alpha in [.9951,.996,.997,.998,1.,1.002,1.003,1.004,1.0049]:
 for noise in [.0003,.003,.01]:
  y,fs,p=waveform(alpha=alpha);y+=np.random.default_rng(617).normal(0,noise,len(y));compare(y,fs,p,dict(kind='affine',alpha=alpha,noise=noise))
for kind in ['warp','missing','noise']:
 for i in range(10):
  if kind=='warp':y,fs,p=waveform(warp=.0002+i*.0002)
  elif kind=='missing':
   y,fs,p=waveform(alpha=.996+i*.0009);start=int((p['pilot_start_samples'][i%7]/48000+.04)*48000);y[start:start+int(.18*48000)]=0
  else:y,fs,p=waveform();y=np.random.default_rng(i).normal(0,.001+i*.002,len(y))
  compare(y,fs,p,dict(kind=kind,index=i))
measured=[]
for sessionpath in sorted((runner.ROOT/'work/external-final-default').glob('*/session.json')):
 session=json.loads(sessionpath.read_text());assert session['probe']['period_s']==.22
 for capture in session['captures']:
  path=sessionpath.parent/capture['recording_path'];y,fs=runner.read_recording(path);row=dict(session=session['session_id'],capture_id=capture['capture_id'],raw_sha256=sha(path),external_transform=capture['external_transform'])
  for label,fn in [('original',runner.process_recording),('candidate',runner.module.process_recording)]:
   r=fn(y,fs,session['probe'],capture['capture_id']);row[label]=dict(status=r['status'],clock=r['clock'],diagnostics=r['diagnostics'],candidates=r['candidates'],direct_arrival_receiver_s=r.get('direct_arrival_receiver_s'))
  measured.append(row)
assert len(measured)==25
summary={label:dict(affine_accepted=sum(r[label]['status']=='ok' for r in rows if r['kind']=='affine'),negative_accepted=sum(r[label]['status']=='ok' for r in rows if r['kind']!='affine'),max_accepted_delay_error_s=max(r[label]['maximum_path_delay_error_s'] for r in rows if r['kind']=='affine' and r[label]['status']=='ok'),measured_accepted=sum(r[label]['status']=='ok' for r in measured)) for label in ['original','candidate']}
save(P/'postfreeze-historical.json',dict(rows=rows,measured=measured,summary=summary,fixture_function_sha256=hashlib.sha256(ast.get_source_segment(source,fn if isinstance(fn,ast.AST) else next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='waveform')).encode()).hexdigest(),candidate_source_sha256=hashlib.sha256(runner.changed.encode()).hexdigest(),scope='Previously exposed27affine/30negative and25hybrid measured-RIR acquisition regressions; no new data or physical-clock validation'))
print(summary)
