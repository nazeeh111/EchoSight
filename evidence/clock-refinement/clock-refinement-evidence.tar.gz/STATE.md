# Clock-refinement branch state

Scope: isolated bounded clock trigger experiment; no production edits/commits. Frozen protocol and initial runner completed1248equal-raw comparisons. All existing1152baseline extractions reproduced. New96cases seeds2701/2713; reserved2609/2621 untouched. Immutable core de8442b.

Result: frozen aggregate gates pass, three≈143ppm clock errors removed, no admission changes. Eleven per-record candidate regressions (seven extra misses) explicitly retained. All24same-core scene per-case plane counts unchanged, including false planes. Historical27affine/30negative and25measured-RIR regressions pass with identical measured outputs. Source-warning classifier not rerun or promoted.

Artifacts: REPORT.md, run-v1/{freeze,results,summary}.json, postfreeze-peak-diagnosis.json, postfreeze-false-candidate-diagnosis.json, postfreeze-scenes/report.json, postfreeze-historical.json. All jobs finished. The independent reviewer has artifact pointers and is reviewing per-record clock uncertainty concerns. Next action: coordinator/reviewer decision on narrow integration, not automatic promotion. No repeated-response estimator started.

Prioritized risks: (1) affine wrong-lobe timing bias can hide in residual; (2) wrong physical direct reference for distributed source; (3) weak/overlapping echo admission can change despite a better clock; (4) no physical device qualification or calibrated clock uncertainty.
