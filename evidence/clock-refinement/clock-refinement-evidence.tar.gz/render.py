"""Independent acquisition-only raw development controls; truth is separate."""
from pathlib import Path
import json,hashlib
import numpy as np
from scipy.signal import chirp,fftconvolve
from scipy.signal.windows import tukey
from scipy.io import wavfile
SEEDS=[2701,2713];PPM=[-4500,-1800,-800,0,800,1800,3500,4500]
FAMILIES=['direct_null','multipath','weak_direct','nonlinear_waveform','nonlinear_clock','step_clock']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def render(folder):
 folder=Path(folder)
 if folder.exists():raise FileExistsError('Preserve previous rendering')
 folder.mkdir();fs=48000;cfg=dict(sample_rate_hz=fs,duration_s=.04,low_hz=2000,high_hz=14000,repetitions=7,period_s=.35,lead_s=.1,tail_s=.18,max_echo_delay_s=.08)
 pulse=.7*chirp(np.arange(1920)/fs,2000,.04,14000,method='linear')*tukey(1920,.25);starts=[round((.1+i*.35)*fs) for i in range(7)];emitted=np.zeros(starts[-1]+len(pulse)+round(.18*fs))
 for start in starts:emitted[start:start+len(pulse)]=pulse
 rows=[]
 for fi,family in enumerate(FAMILIES):
  for seed in SEEDS:
   for ri,ppm in enumerate(PPM):
    rng=np.random.default_rng(seed+fi*10000+ri*101);alpha=1+ppm*1e-6;offset=rng.uniform(.02,.10);paths=[(.004,.45)]
    if family!='direct_null':paths += [(d+.004,g) for d,g in zip([.0012,.0044,.0045,.012],[.24,.18,.12,.10])]
    if family=='weak_direct':paths=[(.004,.018),(.010,.45),(.016,.18)]
    h=np.zeros(round(.025*fs))
    for delay,gain in paths:
     center=delay*fs;indices=np.arange(int(np.floor(center))-24,int(np.floor(center))+25);weights=np.sinc(indices-center)*np.hanning(49);weights/=sum(weights);h[indices]+=gain*weights
    wave=fftconvolve(emitted,h)
    if family=='nonlinear_waveform':wave=np.tanh(3*wave)/3
    source_t=np.arange(len(wave))/fs;receiver_t=offset+alpha*source_t
    if family=='nonlinear_clock':receiver_t+=.0008*np.sin(2*np.pi*source_t/2.5)
    if family=='step_clock':receiver_t+=np.where(source_t>=1.2,.001,0)
    assert np.all(np.diff(receiver_t)>0)
    delivered_t=np.arange(int(np.ceil((receiver_t[-1]+.1)*fs)))/fs;y=np.interp(delivered_t,receiver_t,wave,left=0,right=0)+rng.normal(0,.00005,len(delivered_t));assert max(abs(y))<.95
    key=f'{family}-{seed}-{ppm}';path=folder/(key+'.wav');wavfile.write(path,fs,np.rint(y*32767).astype('<i2'))
    # Public capture input excludes every clock/path annotation.
    entry=dict(case_id=key,recording_path=path.name,probe=cfg,sample_rate_hz=fs,raw_sha256=sha(path));rows.append(entry)
    save(folder/(key+'.truth.json'),dict(family=family,seed=seed,alpha=alpha,offset_s=offset,affine=family not in ['nonlinear_clock','step_clock'],weak_direct=family=='weak_direct',path_delays_s=[x[0] for x in paths],path_amplitudes=[x[1] for x in paths],clock_ppm=ppm,source_distortion=family=='nonlinear_waveform',evidence='Analytic synthetic control, not measured audio'))
 save(folder/'manifest.json',rows);return rows
