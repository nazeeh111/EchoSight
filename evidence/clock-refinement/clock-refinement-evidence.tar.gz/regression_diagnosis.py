from pathlib import Path
import sys,json
import numpy as np
from scipy.signal import correlate,find_peaks
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import runner
from render import save
allrows=json.loads((P/'run-v1/results.json').read_text())['rows'];out=[]
for row in allrows:
 a,b=row['original'],row['candidate']
 if not (b['missed_paths']>a['missed_paths'] or b['false_candidates']>a['false_candidates']):continue
 folder=runner.SOURCE/row['cohort']/'fresh'/row['key'];session_path=folder/f"source-{row['source_index']:02d}/session.json";session=json.loads(session_path.read_text());capture=next(c for c in session['captures'] if c['capture_id']==row['capture_id']);samples,fs=runner.read_recording(session_path.parent/capture['recording_path']);answers={}
 for label,fn in [('original',runner.process_recording),('candidate',runner.module.process_recording)]:
  o=fn(samples,fs,session['probe'],capture['capture_id']);response=np.array(o['response']['values']);srcfs=o['response']['sample_rate_hz'];axis=o['response']['start_delay_s']+np.arange(len(response))/srcfs;envelope=abs(response);threshold=max(envelope.max()*.07,o['quality']['noise_response_amplitude']*12)
  pulse,probe=runner.module.generate_probe(session['probe']);pulse=pulse[probe['pilot_start_samples'][0]:probe['pilot_start_samples'][0]+round(probe['duration_s']*srcfs)];local_t=np.arange(-round(.004*srcfs),round((probe['duration_s']+probe['max_echo_delay_s']+.004)*srcfs))/srcfs
  responses=[]
  for start in np.array(probe['pilot_start_samples'])/srcfs:
   times=o['clock']['alpha']*(start+local_t)+o['clock']['intercept_s'];segment=np.interp(times*fs,np.arange(len(samples)),samples);responses.append(correlate(segment,pulse,mode='valid',method='fft')/(pulse@pulse))
  responses=np.array(responses);assert np.array_equal(np.median(responses,axis=0),response)
  selected,_=find_peaks(envelope,height=threshold,prominence=threshold*.65,distance=round(.00035*srcfs));allpeaks,_=find_peaks(envelope)
  truth=np.array(a['geometric_truth_excess_delays_s']);paths=[]
  for j,t in enumerate(truth):
   near=allpeaks[abs(axis[allpeaks]-t)<=.000075];q=int(near[np.argmax(envelope[near])]) if len(near) else None;separations=abs(truth-t);separations=separations[separations>1e-12]
   paths.append(dict(truth_index=j,delay_s=float(t),nearest_other_truth_separation_s=float(min(separations)) if len(separations) else None,nearby_raw_peak_delay_s=float(axis[q]) if q is not None else None,nearby_raw_peak_relative_amplitude=float(envelope[q]/o['quality']['direct_response_amplitude']) if q is not None else None,threshold_relative_to_direct=float(threshold/o['quality']['direct_response_amplitude']),above_amplitude_threshold=bool(envelope[q]>=threshold) if q is not None else False,passes_peak_selection=bool(q in selected) if q is not None else False,repeat_support=int(sum(abs(responses[:,q])>threshold*.65)) if q is not None else 0))
  answers[label]=dict(paths=paths,candidates=o['candidates'],direct_amplitude=o['quality']['direct_response_amplitude'],clock=o['clock'])
 out.append({k:row.get(k) for k in ['cohort','key','source_index','capture_id']}|dict(original_false=a['false_candidates'],candidate_false=b['false_candidates'],original_missed=a['missed_paths'],candidate_missed=b['missed_paths'],original_matched_truth_indices=[m[1] for m in a['matches']],candidate_matched_truth_indices=[m[1] for m in b['matches']],details=answers))
save(P/'postfreeze-peak-diagnosis.json',out)
for row in out:
 oldset=set(row['original_matched_truth_indices']);newset=set(row['candidate_matched_truth_indices']);print(row['key'],row['source_index'],row['capture_id'],'false',row['original_false'],row['candidate_false'],'miss',row['original_missed'],row['candidate_missed'])
 for j in sorted(oldset-newset):print('  LOST',j,row['details']['candidate']['paths'][j])
