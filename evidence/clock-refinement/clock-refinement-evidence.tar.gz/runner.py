from pathlib import Path
import hashlib,json,sys,time,types,resource
import numpy as np
from scipy.optimize import linear_sum_assignment
P=Path(__file__).resolve().parent;ROOT=P.parents[1];SOURCE=ROOT/'work/source-model-diagnostic';CORE=SOURCE/'run-v4/checkouts/de8442b2dd088c036d2b92eaeaf29a1273785795';sys.path.insert(0,str(CORE))
from echosight.signals import process_recording
from echosight.storage import read_recording
from render import render,save,sha
FILES=[P/'PROTOCOL.md',P/'runner.py',P/'render.py',CORE/'echosight/signals.py',CORE/'echosight/storage.py']
def hashes():return {str(p.relative_to(ROOT)):sha(p) for p in FILES}
source=(CORE/'echosight/signals.py').read_text();old="if np.max(np.abs(residual))>max(2/fs,.00010) and abs(alpha-1)<=.005:";new="if (np.max(np.abs(residual))>max(2/fs,.00010) or abs(alpha-1)*p['duration_s']>.5/(p['high_hz']-p['low_hz'])) and abs(alpha-1)<=.005:"
assert source.count(old)==1
changed=source.replace(old,new).replace("    acquisition_refined=False","    result['development_initial_clock']=dict(alpha=float(alpha),intercept_s=float(intercept),residual_max_s=float(np.max(np.abs(residual))))\n    acquisition_refined=False",1)
module=types.ModuleType('candidate_signals');exec(compile(changed,'candidate_signals','exec'),module.__dict__)
def metric(o,truth):
 out=dict(status=o['status'],diagnostics=o['diagnostics'],clock=o.get('clock'),initial_clock=o.get('development_initial_clock'),candidates=o.get('candidates',[]),direct_std_s=o.get('direct_std_s'),direct_arrival_receiver_s=o.get('direct_arrival_receiver_s'))
 if o.get('clock') and truth['affine']:
  out['rate_error_ppm']=(o['clock']['alpha']-truth['alpha'])*1e6;out['rate_standardized_error']=(o['clock']['alpha']-truth['alpha'])/o['clock']['alpha_std']
 delays=np.array(truth['path_delays_s']);relative=delays-delays.min();relative=relative[relative>1e-12];relative=relative[relative<=.08];pred=np.array([c['delay_s'] for c in o.get('candidates',[])])
 matches=[]
 if len(relative) and len(pred):
  distances=abs(pred[:,None]-relative);a,b=linear_sum_assignment(np.where(distances<=.000075,distances,100.))
  matches=[(int(i),int(j),float(distances[i,j])) for i,j in zip(a,b) if distances[i,j]<=.000075]
 out.update(true_candidates=len(matches),false_candidates=len(pred)-len(matches),missed_paths=len(relative)-len(matches),geometric_truth_excess_delays_s=relative.tolist(),matches=matches)
 out['nearest_path_compatibility']=[]
 if o['status']=='ok':
  for delay in relative:
   if not len(pred):break
   k=int(np.argmin(abs(pred-delay)));c=o['candidates'][k];sd=np.sqrt(c['delay_std_s']**2+o['direct_std_s']**2+(delay*o['clock']['alpha_std']/o['clock']['alpha'])**2)
   out['nearest_path_compatibility'].append(dict(actual_delay_s=float(delay),nearest_delay_s=float(pred[k]),error_s=float(pred[k]-delay),conditional_standardized_residual=float((pred[k]-delay)/sd)))
  expected_direct=truth['offset_s']+truth['alpha']*(.1+float(delays.min()))
  out['physical_direct_error_s']=o['direct_arrival_receiver_s']-expected_direct if truth['affine'] else None
 return out

def main():
 out=P/'run-v1';action=sys.argv[1]
 if action=='freeze':
  if (out/'freeze.json').exists():raise FileExistsError('Preserve freeze')
  save(out/'freeze.json',dict(hashes=hashes(),candidate_source_sha256=hashlib.sha256(changed.encode()).hexdigest(),time_unix=time.time(),before_new_generation=True,existing_v4_snapshot='587df54570155117f92df5a970e47e335a371ecaef31cc16d38f2e6a95108187'));print('Frozen',sha(out/'freeze.json'));return
 assert hashes()==json.loads((out/'freeze.json').read_text())['hashes'];entries=render(out/'raw');jobs=[]
 for cohort in ['run-v3','run-v4']:
  for folder in sorted((SOURCE/cohort/'fresh').iterdir()):
   if not folder.is_dir():continue
   bundle=json.loads((folder/'bundle.json').read_text());saved=json.loads((folder/'baseline.json').read_text())['result']
   for j,rel in enumerate(bundle['sessions']):
    session=json.loads((folder/rel).read_text())
    for i,c in enumerate(session['captures']):jobs.append((cohort,folder.name,j,i,folder/rel,c,session['probe'],saved['processed_sessions'][j]['observations'][i]))
 rows=[]
 for index,job in enumerate(jobs):
  cohort,key,j,i,session_path,c,probe,saved=job;path=session_path.parent/c['recording_path'];rawhash=sha(path);folder=session_path.parent.parent;manifest=json.loads((folder/'manifest.json').read_text());assert rawhash==manifest['recordings'][str(path.relative_to(folder))]
  samples,rate=read_recording(path);start=time.perf_counter();original=process_recording(samples,rate,probe,c['capture_id']);original_time=time.perf_counter()-start;assert original['clock']==saved['clock'];assert original['candidates']==saved['candidates'];assert original['status']==saved['status']
  start=time.perf_counter();candidate=module.process_recording(samples,rate,probe,c['capture_id']);candidate_time=time.perf_counter()-start
  # Load evaluation-only path and clock annotation after both fits.
  t=json.loads((folder/'truth.json').read_text());capture_truth=t['sessions'][j]['captures'][i];truth=dict(family=t['family'],alpha=capture_truth['alpha'],offset_s=capture_truth['offset_s'],path_delays_s=[p['delay_s'] for p in capture_truth['paths']],affine=True,weak_direct=False)
  row=dict(cohort=cohort,key=key,source_index=j,capture_id=c['capture_id'],raw_sha256=rawhash,truth=truth,original=metric(original,truth),candidate=metric(candidate,truth),original_runtime_s=original_time,candidate_runtime_s=candidate_time);rows.append(row)
  if (index+1)%48==0:save(out/'partial-results.json',rows);print('existing',index+1,key,flush=True)
 for index,entry in enumerate(entries):
  samples,rate=read_recording(out/'raw'/entry['recording_path']);answers={};timings={}
  for label,fn in [('original',process_recording),('candidate',module.process_recording)]:
   start=time.perf_counter();answers[label]=fn(samples,rate,entry['probe'],entry['case_id']);timings[label+'_runtime_s']=time.perf_counter()-start
  truth=json.loads((out/'raw'/(entry['case_id']+'.truth.json')).read_text());row=dict(cohort='targeted',key=entry['case_id'],raw_sha256=entry['raw_sha256'],truth=truth,original=metric(answers['original'],truth),candidate=metric(answers['candidate'],truth),**timings);rows.append(row)
  if (index+1)%16==0:save(out/'partial-results.json',rows);print('targeted',index+1,flush=True)
 assert hashes()==json.loads((out/'freeze.json').read_text())['hashes'];save(out/'results.json',dict(rows=rows,hashes=hashes(),candidate_source_sha256=hashlib.sha256(changed.encode()).hexdigest(),all_existing_extractions_exactly_reproduced=True,peak_process_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss));print('Complete',len(rows),flush=True)
if __name__=='__main__':main()
