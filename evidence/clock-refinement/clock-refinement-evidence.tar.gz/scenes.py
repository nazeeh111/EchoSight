"""Authorized postfreeze same-mapper scene regression, no thresholds changed."""
from pathlib import Path
import json,time,copy,sys,hashlib
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P))
import runner
sys.path.append(str(runner.ROOT))
from echosight.multisource import infer_scene_bundle
from evaluation.metrics import score_surfaces
from render import save,sha
rows=[];out=P/'postfreeze-scenes';out.mkdir(exist_ok=False)
for cohort in ['run-v3','run-v4']:
 for folder in sorted((runner.SOURCE/cohort/'fresh').iterdir()):
  if not folder.is_dir():continue
  saved=json.loads((folder/'baseline.json').read_text())['result'];bundle=json.loads((folder/'bundle.json').read_text());base=saved['processed_sessions'];alternative=copy.deepcopy(base)
  for item in alternative:
   for o in item['observations']:
    c=next(c for c in item['session']['captures'] if c['capture_id']==o['capture_id']);samples,rate=runner.read_recording(Path(c['recording_path']));fresh=runner.module.process_recording(samples,rate,item['session']['probe'],o['capture_id']);o.update(fresh)
  answers={};timings={}
  for label,processed in [('original',base),('candidate',alternative)]:
   start=time.perf_counter();answers[label]=infer_scene_bundle(processed,bundle);timings[label]=time.perf_counter()-start
  # Truth accessed only after both same-input mapper arms finish.
  truth=json.loads((folder/'truth.json').read_text());scores={k:score_surfaces(v,truth) for k,v in answers.items()};previous=score_surfaces(saved,truth)
  assert {k:scores['original'][k] for k in ['matched_count','false_surfaces','missed_surfaces']}=={k:previous[k] for k in ['matched_count','false_surfaces','missed_surfaces']}
  row=dict(cohort=cohort,key=folder.name,scores=scores,runtime_s=timings,baseline_score_reproduced=True,source_baseline_sha256=sha(folder/'baseline.json'),raw_manifest_sha256=sha(folder/'manifest.json'));rows.append(row)
  for label,result in answers.items():save(out/(cohort+'-'+folder.name+'-'+label+'.json'),result)
  save(out/'progress.json',rows);print(cohort,folder.name,[(k,scores[k]['matched_count'],scores[k]['false_surfaces'],scores[k]['missed_surfaces']) for k in scores],flush=True)
summary={g:{label:{key:sum(r['scores'][label][key] for r in rows if r['cohort']==g) for key in ['matched_count','false_surfaces','missed_surfaces']} for label in ['original','candidate']} for g in ['run-v3','run-v4']}
save(out/'report.json',dict(rows=rows,summary=summary,core_commit='de8442b2dd088c036d2b92eaeaf29a1273785795',candidate_source_sha256=hashlib.sha256(runner.changed.encode()).hexdigest(),scope='Postfreeze regression on previously exposed scenes; no source-warning classifier.'))
print(summary,flush=True)
