# EchoSight synthetic recording case

Public default backend/implementation8759b0faa462b47d35bfc7d46755bc32e21cca1a. Python3.12.13 NumPy2.3.5 SciPy1.18.1. Install this exact project source and dependencies, then from this fresh extracted directory choose new output paths:

    python -m echosight replay raw-session.zip --store replay-store --output replayed.json
    python -m echosight process input-session.json --output recomputed.json

All twelve named original WAVs and probe are included. Input session recording paths resolve inside the bundle. raw-session.zip is the native reopenable archive and contains original current metadata/result before the later calibration edit. Its old computation is quarantined on import; fresh processing is required.
The twelve-view status is partial with six reflection-support hulls; five views remain ambiguous. Neither establishes wall edges, safe space or physical room accuracy. Processing replays can change timing and replay metadata; compare exact recording hashes and scoped geometry arrays, not whole result hashes.
figure.py reads five/twelve-view JSON from this directory and draws their source-derived plot. No measured ultrasound input, private recording or hardware data is included. The measured PHANTOM route remains separate.
All MANIFEST.json paths are included. Original backend MIT applies only to existing exact scope, preserved under scope/. This bundle does not broaden that grant over room assets, upstream adaptations or unlisted material. Source and third-party notices remain in the complete repository.
